﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Task_1 {
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow :Window {
        public MainWindow() {
            InitializeComponent();

            for(int i = 1; i <= 20; i++) {
                cbRow.Items.Add(i);
                cbColumn.Items.Add(i);
            }
            cbRow.SelectedItem = 1; 
            cbColumn.SelectedItem = 1;
        }

        DataTable Currentdt = new DataTable();


        private void cbRow_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            UpdateMatrix();
        }

        private void cbColumn_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            UpdateMatrix();
        }

        public void UpdateMatrix() {
            if(cbColumn.Text.ToString() == "" || cbRow.Text.ToString() == "") return;
            int x = int.Parse(cbColumn.SelectedItem.ToString());
            int y = int.Parse(cbRow.SelectedItem.ToString());

            var dt = new DataTable();

            for(int i = 1; i <= x+1; i++) dt.Columns.Add(new DataColumn($"{i}"));
            for(int i = 1; i <= y; i++) dt.Rows.Add();

            dgMatrix.ItemsSource = dt.DefaultView;
            Currentdt = dt;
        }

        private void btnBuildBasicPlanOne_Click(object sender, RoutedEventArgs e) {

            if(!CheckBalance()) return;

            int y = int.Parse(cbRow.Text);
            int x = int.Parse(cbColumn.Text);

            int[,] defaultMatrix = new int[y, x];
            int[,] costs = new int[y, x];
            int[] supply = new int[y];
            int[] demand = new int[x];
            int C = 0;

            for(int i = 0; i < y; i++) {
                for(int j = 0; j < x; j++) {
                    costs[i, j] = int.Parse(Currentdt.Rows[i][j].ToString());
                    defaultMatrix[i, j] = int.Parse(Currentdt.Rows[i][j].ToString());
                }
            }

            for(int i = 0; i < x; i++) demand[i] = int.Parse(Currentdt.Rows[y][i].ToString());
            for(int j = 0; j < y; j++) supply[j] = int.Parse(Currentdt.Rows[j][x].ToString());

            int curX = 0;
            int curY = 0;

            while(true) {
                if(curY < y - 1 || curX < x - 1) {
                    if(supply[curY] > demand[curX]) {
                        int num = demand[curX];
                        for(int i = curY; i < y; i++) costs[i, curX] = 0;
                        costs[curY, curX] = num;
                        supply[curY] = supply[curY] - num;
                        demand[curX] = 0;
                        curX++;
                    }
                    else if(supply[curY] < demand[curX]) {
                        int num = supply[curY];
                        for(int i = curX; i < x; i++) costs[curY, i] = 0;
                        costs[curY, curX] = num;
                        demand[curX] = demand[curX] - num;
                        supply[curY] = 0;
                        curY++;
                    }
                    else if (supply[curY] == demand[curX]){
                        int num = supply[curY];
                        for(int i = curX; i < x; i++) costs[curY, i] = 0;
                        for(int i = curY; i < y; i++) costs[i, curX] = 0;
                        costs[curY, curX] = num;
                        demand[curX] = 0;
                        supply[curY] = 0;
                        curY++;
                        curX++;
                    }
                }
                else {
                    if(curY == y-1) {
                        costs[curY, curX] = demand[curX];
                    }
                    else if(curX == x-1) {
                        costs[curY, curX] = supply[curY];
                    }
                    break;
                }
            }

            for(int i = 0; i < y; i++) {
                for(int j = 0; j < x; j++) {
                    Currentdt.Rows[i][j] = costs[i, j];
                    C += costs[i, j] * defaultMatrix[i, j];
                }
            }

            dgMatrix.ItemsSource = Currentdt.DefaultView;
            lblC.Content = $"C = {C}";
        }

        private void btnBuildBasicPlanTwo_Click(object sender, RoutedEventArgs e) {

            if(!CheckBalance()) return;

            int y = int.Parse(cbRow.Text);
            int x = int.Parse(cbColumn.Text);

            int[,] defaultMatrix = new int[y, x];
            int[,] costs = new int[y, x];
            int[] supply = new int[y];
            int[] demand = new int[x];

            int C = 0;

            for(int i = 0; i < y; i++) {
                for(int j = 0; j < x; j++) {
                    costs[i, j] = int.Parse(Currentdt.Rows[i][j].ToString());
                    defaultMatrix[i, j] = int.Parse(Currentdt.Rows[i][j].ToString());
                }
            }

            for(int i = 0; i < x; i++) demand[i] = int.Parse(Currentdt.Rows[y][i].ToString());
            for(int j = 0; j < y; j++) supply[j] = int.Parse(Currentdt.Rows[j][x].ToString());

            int[,] plan = new int[y, x];
            for(int i = 0; i < y; i++) {
                for(int j = 0; j < x; j++) {
                    plan[i, j] = 0;
                }
            }

            int[] remainingSupply = new int[y]; 
            int[] remainingDemand = new int[x]; 

            Array.Copy(supply, remainingSupply, y); // копируем начальные запасы
            Array.Copy(demand, remainingDemand, x); // копируем начальные потребности

            while(!IsPlanComplete(remainingSupply, remainingDemand)) {
                // Находим минимальный элемент среди всех возможных клеток
                int minCost = Int32.MaxValue;
                int minI = -1;
                int minJ = -1;

                for(int i = 0; i < y; i++) {
                    if(remainingSupply[i] == 0) continue; // этот поставщик уже исчерпал свои запасы

                    for(int j = 0; j < x; j++) {
                        if(remainingDemand[j] == 0) continue; // этот потребитель уже удовлетворил свою потребность

                        if(costs[i, j] != -1 && costs[i, j] < minCost) {
                            minCost = costs[i, j];
                            minI = i;
                            minJ = j;
                        }
                    }
                }

                if(minCost == Int32.MaxValue) {
                    for(int j = 0; j < x; j++) {
                        if(remainingDemand[j] == 0) continue;

                        for(int i = 0; i < y; i++) {
                            if(remainingSupply[i] == 0) continue; // этот потребитель уже удовлетворил свою потребность

                            if(costs[i, j] != -1 && costs[i, j] < minCost) {
                                minCost = costs[i, j];
                                minI = i;
                                minJ = j;
                            }
                        }
                    }
                }

                int quantity;

                quantity = Math.Min(remainingSupply[minI], remainingDemand[minJ]);
                plan[minI, minJ] = quantity;
                remainingSupply[minI] -= quantity;
                remainingDemand[minJ] -= quantity;
                costs[minI, minJ] = -1;
            }

            for(int i = 0; i < y; i++) {
                for(int j = 0; j < x; j++) {
                    Currentdt.Rows[i][j] = plan[i, j];
                    C += defaultMatrix[i, j] * plan[i, j];
                }
            }

            dgMatrix.ItemsSource = Currentdt.DefaultView;
            lblC.Content = $"C = {C}";
        }

        static bool IsPlanComplete(int[] remainingSupply, int[] remainingDemand) {
            foreach(var s in remainingSupply) {
                if(s > 0) return false;
            }

            foreach(var d in remainingDemand) {
                if(d > 0) return false;
            }

            return true;
        }

        public bool CheckBalance() {
            int n = int.Parse(cbColumn.Text);
            int m = int.Parse(cbRow.Text);

            int[] supply = new int[m];
            int[] demand = new int[n];

            for(int i = 0; i < m; i++) {
                for(int j = 0; j < n; j++) {
                    supply[i] = int.Parse(Currentdt.Rows[i][n].ToString());
                    demand[j] = int.Parse(Currentdt.Rows[m][j].ToString());
                }
            }

            if(supply.Sum() != demand.Sum()) {
                MessageBox.Show("Матрица не сбалансирована");
                return false;
            }

            return true;
        }
    }
}
